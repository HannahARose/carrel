#!/bin/sh
probe-rs run --chip RP2040 target/thumbv6m-none-eabi/release/lamp-dimmer
