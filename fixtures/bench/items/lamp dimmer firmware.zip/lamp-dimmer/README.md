# Lamp dimmer

Firmware for the desk lamp's PWM dimmer: a rotary encoder sets the brightness of the LED strip, and the last level is kept across power cuts.

Build with `cargo build --release` and flash with probe-rs.
