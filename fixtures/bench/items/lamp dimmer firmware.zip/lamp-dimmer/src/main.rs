#![no_std]
#![no_main]

// Reads the encoder and sets the PWM duty cycle.
fn main() {}
